package com.example.aydsII;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AydsIiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AydsIiApplication.class, args);
	}

}
